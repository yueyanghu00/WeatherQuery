package com.example.myapplication;

import androidx.annotation.LongDef;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private List<Information> informationList = new ArrayList<>();
    private InformationAdapter adapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonInputWeight = findViewById(R.id.button_input_weight);
        Button buttonInputHeight = findViewById(R.id.button_input_height);

        buttonInputWeight.setOnClickListener(this);
        buttonInputHeight.setOnClickListener(this);

        initInformation();
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new InformationAdapter(informationList);
        recyclerView.setAdapter(adapter);

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new MyItemTouchCallBack(adapter));
        itemTouchHelper.attachToRecyclerView(recyclerView);


    }


    @Override
    public void onClick(View view){
        Log.d("hyy", "onClick: ");
        int id = view.getId();
        switch (id){
            case R.id.button_input_weight:
                showInputWeight();
                break;
            default:
        }
    }


    @Override
    public void onStop(){
        super.onStop();
        Log.d("hyy_test_activity", "onStop: ");
    }

    @Override
    public void onRestart(){
        super.onRestart();
        Log.d("hyy_test_activity", "onRestart: ");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("hyy", "onDestroy: ");
        save_weight();
    }

    public String getTime(){
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String nowTime  = df.format(new Date());
        return nowTime;
    }

    public void save_weight(){
        FileOutputStream out = null;
        BufferedWriter writer = null;
        try{
            out = openFileOutput("data", Context.MODE_PRIVATE);
            writer = new BufferedWriter(new OutputStreamWriter(out));
            for(Information info : informationList){
                Log.d("hyy", "save_weight: "+info.getInformationToLoad());
                writer.write(info.getInformationToLoad());
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }finally{
            try{
                if(writer!=null){
                    writer.close();
                }
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }

    public List<String> load_weight(){
        FileInputStream in = null;
        BufferedReader reader = null;
        List<String> content = new ArrayList<>();
        try{
            in = openFileInput("data");
            reader = new BufferedReader(new InputStreamReader(in));
            String line = "";
            while((line = reader.readLine())!=null){
                content.add(line);
            }
        } catch (IOException e){
            e.printStackTrace();
        }finally {
            if (reader!=null){
                try{
                    reader.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }
        return content;
    }

    private void showInputWeight() {
        final EditText editText = new EditText(this);
        AlertDialog.Builder builder = new AlertDialog.Builder(this).setTitle("请输入体重").setView(editText)
                .setPositiveButton("完成", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Information newInformation = new Information(getTime(),
                                Integer.parseInt(editText.getText().toString()),
                                0);
                        informationList.add(newInformation);
                        adapter.notifyDataSetChanged();
//                        String inputText = getTime()+"~"+editText.getText().toString()+"\n";
//                        save_weight(inputText);
//
//                        Toast.makeText(MainActivity.this, "输入内容为：" + inputText
//                                , Toast.LENGTH_LONG).show();
                    }
                });
        builder.create().show();
    }

    private void initInformation(){
        List<String> informations = load_weight();
        Information temp = null;
        for(String line:informations){
            Log.d("init information", "initInformation: "+line);
            String[] words = line.split("~");
            temp = new Information(words[0],Integer.parseInt(words[1]),0);
            informationList.add(temp);
        }
        Log.d("hyy", "initInformation: good");
    }

}