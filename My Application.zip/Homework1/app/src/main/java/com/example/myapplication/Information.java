package com.example.myapplication;


import android.util.Log;

public class Information {
    private String date;
    int weight,height;
    public Information(String date, int weight, int height){
        this.date=date;
        this.weight=weight;
        this.height=height;
    }
    public int getHeight() {
        return height;
    }
    public int getWeight() {
        return weight;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
    public String getInformation(){
        return date+"    "+String.valueOf(weight)+"KG";
    }
    public String getInformationToLoad(){
        return date+"~"+String.valueOf(weight)+"\n";
    }
}
